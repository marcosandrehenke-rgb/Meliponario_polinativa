# Meliponário Polinativa — Android

Projeto Android nativo com WebView, usando o aplicativo de monitoramento em assets/index.html.

## Gerar APK
1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle sincronizar.
3. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
4. O APK será gerado em:
   app/build/outputs/apk/debug/app-debug.apk

## Instalação
Envie o app-debug.apk para o Android, toque nele e permita a instalação de aplicativos desta fonte quando o Android solicitar.

O aplicativo funciona offline e salva os dados no armazenamento local do WebView.
